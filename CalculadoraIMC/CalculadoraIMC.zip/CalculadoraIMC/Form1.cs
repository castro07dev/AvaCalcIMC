﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraIMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void btnResul_Click(object sender, EventArgs e)
        {
            double pesoC = Convert.ToDouble(txtPeso.Text);
            double altura = Convert.ToDouble(txtAltura.Text);
            double resultado = pesoC / (altura * 2);
            txtResult.Text = resultado.ToString();
            
            //calculos para chegar no resultado do imc
        }

      

        private void txtPeso_Enter(object sender, EventArgs e)
        {
            txtAltura.Tag = false;
            txtPeso.Tag = true;
        }

        private void txtAltura_Enter(object sender, EventArgs e)
        {
            txtAltura.Tag = true;
            txtPeso.Tag = false;
        }

        private void button14_Enter(object sender, EventArgs e)
        {
            Button numeros = sender as Button;

            if (txtAltura.Tag.Equals(true))
            {
                txtAltura.Text += numeros.Text;

            }
            else
            {
                txtPeso.Text += numeros.Text;
            }
        }
    }
}
